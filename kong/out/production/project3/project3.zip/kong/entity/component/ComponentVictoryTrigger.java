package kong.entity.component;

public class ComponentVictoryTrigger extends ComponentCollisionBox {
    public ComponentVictoryTrigger(int xHalfExtent, int yHalfExtent) {
        super(xHalfExtent, yHalfExtent);
    }
}
