package kong.entity.component;

public class ComponentMovingBar implements Component {
    public float leftEdge;
    public float rightEdge;

    public float speed = 2.1f;
}
