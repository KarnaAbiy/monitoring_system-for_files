package kong.entity.component;

public class ComponentDynamicCollisionBox extends ComponentCollisionBox {
    public ComponentDynamicCollisionBox(int xHalfExtent, int yHalfExtent) {
        super(xHalfExtent, yHalfExtent);
    }
}
