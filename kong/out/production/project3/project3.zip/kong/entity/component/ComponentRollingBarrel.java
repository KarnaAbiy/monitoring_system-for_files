package kong.entity.component;

public class ComponentRollingBarrel extends ComponentRollingObject {
}
