package kong.entity.component;

public class ComponentLadder extends ComponentCollisionBox {
    public ComponentLadder(int xHalfExtent, int yHalfExtent) {
        super(xHalfExtent, yHalfExtent);
    }
}
