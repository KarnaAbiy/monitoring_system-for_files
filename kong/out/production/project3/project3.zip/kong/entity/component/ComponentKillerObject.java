package kong.entity.component;

public class ComponentKillerObject implements Component {
}
