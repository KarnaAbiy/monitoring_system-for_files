package kong.entity.component;

public class ComponentVelocity implements Component {
    public float xVel = 0, yVel = 0;

    public boolean onGround = false;
}
