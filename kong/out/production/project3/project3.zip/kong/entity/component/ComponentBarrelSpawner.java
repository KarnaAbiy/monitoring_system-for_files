package kong.entity.component;

public class ComponentBarrelSpawner implements Component {
    public int spawnRate = 60;
    public int remainingTicksToSpawn = 60;
}
