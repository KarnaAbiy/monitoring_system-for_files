package kong.entity.component;

public interface Component {
}
