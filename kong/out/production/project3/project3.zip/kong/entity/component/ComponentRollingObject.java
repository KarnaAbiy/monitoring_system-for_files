package kong.entity.component;

public class ComponentRollingObject extends ComponentVelocity {
}
